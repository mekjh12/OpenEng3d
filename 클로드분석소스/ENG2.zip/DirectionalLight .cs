﻿using Common.Abstractions;

namespace Lights
{
    public class DirectionalLight : Light
    {



    }
}
