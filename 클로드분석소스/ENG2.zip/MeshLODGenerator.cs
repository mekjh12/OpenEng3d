﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model3d
{
    internal class MeshLODGenerator
    {
        //3D 메시 단순화(Mesh Simplification)를 위한 주요 알고리즘과 방법들을 설명드리겠습니다:
        // 에지 축소(Edge Collapse)
        // Quadric Error Metrics (QEM)
        // Vertex Clustering
        // Progressive Meshes
    }
}
