﻿namespace Animate
{
    /// <summary>
    /// 뼈대 enum의 공통 인터페이스
    /// </summary>
    public interface IBoneEnum
    {
        string ToRigName();
    }
}
