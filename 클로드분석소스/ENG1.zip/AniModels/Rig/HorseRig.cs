﻿using OpenGL;

namespace Animate
{
    public class HorseRig : AnimRig
    {

        public HorseRig(string filename, string hipBoneName, bool isLoadAnimation = true) : base(filename, hipBoneName, isLoadAnimation)
        {
            
        }
    }
}
