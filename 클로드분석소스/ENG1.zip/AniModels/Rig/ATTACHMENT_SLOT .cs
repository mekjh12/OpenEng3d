﻿namespace Animate
{
    public enum ATTACHMENT_SLOT
    {
        LeftHand, 
        RightHand, 
        Head, 
        Back, 
        Count
    }
}
