﻿namespace Animate
{
    public class BirdRig : AnimRig
    {

        public BirdRig(string filename,string hipBoneName, bool isLoadAnimation = true) : base(filename, hipBoneName, isLoadAnimation)
        {
            
        }
    }
}
