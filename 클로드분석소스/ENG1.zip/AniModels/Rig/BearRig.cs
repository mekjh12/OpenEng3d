﻿namespace Animate
{
    public class BearRig : AnimRig
    {

        public BearRig(string filename, string hipBoneName, bool isLoadAnimation = true) : base(filename, hipBoneName, isLoadAnimation)
        {
            
        }
    }
}
