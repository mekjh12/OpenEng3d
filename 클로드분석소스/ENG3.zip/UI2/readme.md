# 2d 컨트롤 작업
- control ---> Pannel ---> Label
  Text-----------------------|

- 보완할 작업
* Form의 우선 순위에 따라 드래그앤드롭
* TextBox구현
* Button의 상속화
