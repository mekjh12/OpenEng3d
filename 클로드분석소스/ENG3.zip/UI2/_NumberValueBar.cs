﻿namespace UIDesign2d
{
    class NumberValueBar
    {
    }
}
