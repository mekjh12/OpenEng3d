﻿namespace UIDesign2d
{
    class RadialMenu
    {
        //pickup과 연계해서 구현하면 좋을듯

    }
}
