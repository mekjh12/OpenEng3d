﻿namespace Ui2d
{
    public class UI2
    {
        public static string NewLine = " <br> ";

        public static string EndOfString = "";
    }
}
