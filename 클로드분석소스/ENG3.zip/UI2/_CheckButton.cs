﻿namespace UIDesign2d
{
    class CheckButton : ImageButton2
    {
        public CheckButton(string name, FontFamily fontFamily) : base(name)
        {

        }
    }
}
