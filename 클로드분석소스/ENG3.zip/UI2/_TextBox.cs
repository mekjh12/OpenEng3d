﻿namespace UIDesign2d
{
    class TextBox : Label
    {
        public TextBox(string name, FontFamily fontFamily) : base(name, fontFamily)
        {

        }
    }
}
