﻿namespace UIDesign2d
{
    class CButton : Label
    {
        public CButton(string name, FontFamily fontFamily) : base(name, fontFamily)
        {

        }
    }
}
