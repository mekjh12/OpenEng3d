﻿using OpenGL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Physics.Collision
{
    public class CollisionPrimitiveSet : CollisionPrimitive
    {
        public CollisionPrimitiveSet(Vertex3f position) : base(position)
        {

        }
    }
}
