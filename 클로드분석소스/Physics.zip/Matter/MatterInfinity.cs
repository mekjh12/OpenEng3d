﻿namespace Physics
{
    public class MatterInfinity : Matter
    {
        public MatterInfinity()
        {
            _specificGravity = SpecificGravityList.Infinity;
        }
    }
}
