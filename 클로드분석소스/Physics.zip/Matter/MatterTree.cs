﻿namespace Physics
{
    public class MatterTree : Matter
    {
        public MatterTree()
        {
            _specificGravity = SpecificGravityList.Tree;
        }
    }
}
