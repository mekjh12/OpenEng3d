﻿namespace Physics
{
    public class MatterIron : Matter
    {
        public MatterIron()
        {
            _specificGravity = SpecificGravityList.Fe;
        }
    }
}
