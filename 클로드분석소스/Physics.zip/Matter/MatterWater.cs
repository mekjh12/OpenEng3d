﻿namespace Physics
{
    public class MatterWater : Matter
    {
        public MatterWater()
        {
            _specificGravity = SpecificGravityList.Water;
        }
    }
}
