﻿namespace Physics
{
    public class ParticleForceRegistration
    {
        public Particle Particle;
        public IParticleForceGenerator ForceGenerator;
    }

}
